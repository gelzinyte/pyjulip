from setuptools import setup

setup(
    name='pyjulip',
    version='0.1',
    scripts=['pyjulip.py']
)
